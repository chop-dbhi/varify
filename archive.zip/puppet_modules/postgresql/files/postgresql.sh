export PATH=/usr/pgsql-9.2/bin:$PATH
