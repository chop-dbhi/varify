CREATE INDEX "variant_chr_id_pos" ON "variant" ("chr_id", "pos");
