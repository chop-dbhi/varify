// RequireJS optimization configuration
// Full example: https://github.com/jrburke/r.js/blob/master/build/example.build.js

({
    // the source directory of the modules
    appDir: 'src',

    // optiize relative to this url (i.e. the current directory)
    baseUrl: '.',

    // the target directory of the optimized modules
    dir: 'min',

    optimize: 'uglify',

    optimizeCss: 'none',

    preserveLicenseComments: false,

    paths: {
        'app': '.',
        'raven': './lib/raven',
        'jquery': 'empty:',
        'underscore': 'empty:',
        'backbone': 'empty:',
        'router': 'empty:',
        'session': 'empty:',
        'mediator': 'empty:',
        'serrano': 'empty:',
        'environ': 'empty:',
        'views/counter': 'empty:',
        'utils/numbers': 'empty:',
        'views/columns': 'empty:'
    },

    modules: [{
        name: 'app/analysis/guide',
        include: ['app/controls', 'app/analysis/controls']
    }, {
        name: 'app/routes/review',
        include: ['app/review/views', 'app/review/models']
    }, {
        name: 'app/review/views',
        include: ['app/review/models']
    }]
})
