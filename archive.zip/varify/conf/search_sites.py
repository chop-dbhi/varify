import haystack
haystack.autodiscover()
