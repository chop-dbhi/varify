from django.contrib import admin
from .models import Genome, Genotype


admin.site.register(Genome)
admin.site.register(Genotype)
